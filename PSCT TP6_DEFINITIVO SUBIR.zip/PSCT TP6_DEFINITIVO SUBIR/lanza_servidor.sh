#! /bin/bash
# Script con la finalidad de lanzar el servidor en un puerto

echo "Puerto seleccionado: $1"
echo "Lanzando servidor..."

./bin/Servidor $1
